package com.mergedata.server.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.mergedata.constants.ReqConstant;
import com.mergedata.dto.ApiRequest;
import com.mergedata.dto.ApiRequestHead;
import com.mergedata.dto.ApiResponse;
import com.mergedata.dto.HisIncomeDTO;
import com.mergedata.entity.BusinessException;
import com.mergedata.dto.CommonRequestBody;
import com.mergedata.util.RestApiUtil; // 导入新的工具类
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;


@Service
@Slf4j
public class ExternalApiRequestService {

    @Value("${api.urls.hisincome}")
    private String URL_API_HISINCOME;

    @Autowired
    private ApiRequestHead headConfig; // 注入 Head 配置

    // 注入新的工具类
    @Autowired
    private RestApiUtil restApiUtil;

    // 为了实现 String 方法中的手动解析，仍然需要 ObjectMapper
    private final ObjectMapper objectMapper = new ObjectMapper().setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);


    /**
     * 调用HIS收入数据接口 - 使用 ParameterizedTypeReference (推荐)
     * @param reportdate 报表日期
     * @return HIS收入数据，调用失败返回空列表
     */
    public List<HisIncomeDTO> getHisIncomeList(String reportdate) {
        log.info("开始调用 HIS 收入 API (TypeRef): {}", URL_API_HISINCOME);

        // 1. 组装请求对象
        CommonRequestBody body = new CommonRequestBody();
        body.setReportdate(reportdate);
        headConfig.setMethod(ReqConstant.METHOD_HISINCOME);
        ApiRequest<CommonRequestBody> apiRequest = new ApiRequest<>();
        apiRequest.setHead(headConfig);
        apiRequest.setBody(body);

        // 2. 定义复杂的返回类型 (核心：告诉工具类期望的类型)
        // 外部 ApiResponse<List<HisIncomeDTO>> 结构
        ParameterizedTypeReference<ApiResponse<List<HisIncomeDTO>>> typeRef =
                new ParameterizedTypeReference<ApiResponse<List<HisIncomeDTO>>>() {};

        try {
            // 3. 调用工具类发起请求
            ApiResponse<List<HisIncomeDTO>> apiResponse = restApiUtil.postForObject(
                    URL_API_HISINCOME,
                    apiRequest, // 传入完整的请求报文对象
                    typeRef
            );

            // 4. 检查业务状态码 (核心判断逻辑)
            if (apiResponse.getResult().isSuccess()) {
                log.info("调用成功，业务处理成功。");
                // 使用 Optional 避免 NulLPointerExcetion
                return Optional.ofNullable(apiResponse.getBody())
                        .map(b -> b.getList())
                        .orElse(Collections.emptyList());
            } else {
                // HTTP 200 OK，但业务状态码非 10000 (业务失败)
                String errMsg = String.format("HIS接口业务失败。Code: %s, Msg: %s",
                        apiResponse.getResult().getCode(), apiResponse.getResult().getSub_msg());
                log.error(errMsg);
                // 抛出业务异常，由上层统一处理
                throw new BusinessException(errMsg);
            }

        } catch (BusinessException e) {
            // 捕获工具类抛出的业务/连接/HTTP异常，记录并返回空列表（或根据业务需求重新抛出）
            log.error("HIS 收入 API 调用失败: {}", e.getMessage());
            return Collections.emptyList();
        }
    }


    /**
     * 调用HIS收入数据接口 - 接收 String 手动解析
     * @param reportdate 报表日期
     * @return HIS收入数据，调用失败返回空列表
     */
    public List<HisIncomeDTO> getHisIncomeList_String(String reportdate) {
        log.info("开始调用 HIS 收入 API (String): {}", URL_API_HISINCOME);

        // 1. 组装请求对象
        CommonRequestBody body = new CommonRequestBody();
        body.setReportdate(reportdate);
        headConfig.setMethod(ReqConstant.METHOD_HISINCOME);
        headConfig.setTimestamp(String.valueOf(System.currentTimeMillis())); // 设置时间戳
        ApiRequest<CommonRequestBody> apiRequest = new ApiRequest<>();
        apiRequest.setHead(headConfig);
        apiRequest.setBody(body);

        try {
            // 2. 调用工具类发起请求，接收原始 String
            String jsonBody = restApiUtil.postForString(URL_API_HISINCOME, apiRequest);

            // 3. 手动进行 JSON 解析和业务判断
            TypeReference<ApiResponse<List<HisIncomeDTO>>> apiTypeRef =
                    new TypeReference<ApiResponse<List<HisIncomeDTO>>>() {};

            // 第一次解析：获取整个结构
            ApiResponse<List<HisIncomeDTO>> apiResponse = objectMapper.readValue(jsonBody, apiTypeRef);

            String responseCode = apiResponse.getResult().getCode();

            if (ReqConstant.API_RESPONSE_SUCCESS.equals(responseCode) || "10000".equals(responseCode)) {
                // 业务成功
                log.info("调用成功，业务处理成功。");
                return Optional.ofNullable(apiResponse.getBody())
                        .map(b -> b.getList())
                        .orElse(Collections.emptyList());

            } else {
                // 业务失败 (例如 40001)
                String msg = String.format("HIS接口业务失败。Code: %s, Msg: %s",
                        responseCode, apiResponse.getResult().getSub_msg());
                log.error(msg);
                // 抛出业务异常
                throw new BusinessException(msg);
            }

        } catch (JsonProcessingException e) {
            log.error("调用失败，JSON处理错误: {}", URL_API_HISINCOME, e);
            return Collections.emptyList();
        } catch (BusinessException e) {
            // 捕获工具类抛出的异常和业务逻辑抛出的异常
            log.error("HIS 收入 API 调用失败: {}", e.getMessage());
            return Collections.emptyList();
        }
    }
}