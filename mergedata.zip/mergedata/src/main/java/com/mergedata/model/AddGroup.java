package com.mergedata.model;

public interface AddGroup {
}
