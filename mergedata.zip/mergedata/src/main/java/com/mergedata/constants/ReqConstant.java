package com.mergedata.constants;

public class ReqConstant {
    // 现金存储过程名称
    public static final String URL_HISINCOME ="http://168.168.235.88:18401/orgine/powermsp/service/overt";

    public static final String METHOD_HISINCOME ="orgine.powermsp.service.overt.extend.SP_GetHisIncome_938";

    public static final String METHO_YQ_OPERATOR ="";

    //节假日存储过程名称
    public static final String PRC_HolidayCalendar ="";
    //


}
