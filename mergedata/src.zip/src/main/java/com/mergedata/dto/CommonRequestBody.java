package com.mergedata.dto;

import lombok.Data;

@Data
public class CommonRequestBody {
    private String reportdate;
    private String extendParams1;
    private String extendParams2;
    private String extendParams3;
}
