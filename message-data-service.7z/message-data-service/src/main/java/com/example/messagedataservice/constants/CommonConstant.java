package com.example.messagedataservice.constants;

public class CommonConstant {
    // 现金存储过程名称
    public static final String PRC_His_CashStatistics ="";

    public static final String PRC_YQ_CashStatistics ="";

    //节假日存储过程名称
    public static final String PRC_HolidayCalendar ="";
    //


}
