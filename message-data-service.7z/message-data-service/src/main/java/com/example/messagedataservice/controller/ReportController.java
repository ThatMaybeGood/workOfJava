package com.example.messagedataservice.controller;

import com.example.messagedataservice.dto.ReportDTO;
import com.example.messagedataservice.server.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * @author Mine
 * @version 1.0
 * 描述:
 * @date 2025/11/10 17:03
 */

@RestController
@RequestMapping("/reportapi")
@CrossOrigin(origins = "*")
public class ReportController {

    @Autowired
    private ReportService reportService;

    @GetMapping("/data")
    public Result<List<ReportDTO>> getData(@RequestParam LocalDate reportDate) {

        return Result.success(reportService.getAll(reportDate));
    }


    @GetMapping("/")
    public Result<String> getHolidayApiInfo() {
        return Result.success("API服务已启动，可用端点：/data, /insert");
    }

}
