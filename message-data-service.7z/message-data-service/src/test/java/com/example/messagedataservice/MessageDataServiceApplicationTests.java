package com.example.messagedataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageDataServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
